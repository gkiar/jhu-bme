histograms = sign(histograms).*sqrt(abs(histograms)) ;
testHistograms = sign(testHistograms).*sqrt(abs(testHistograms)) ;

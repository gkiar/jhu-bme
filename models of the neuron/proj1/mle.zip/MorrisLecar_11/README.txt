
Simple versions of MLE simulator for Project 1.
These were revised in 2011 for the recent versions of the ODE solvers.

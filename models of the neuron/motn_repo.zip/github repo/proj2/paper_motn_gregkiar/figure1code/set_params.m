function set_params(Iext, Gs, Gg, Gc, C, B, arr, ad, Ec, Ej, vth)

global Iext1 Gs1 Gg1 Gc1 C1 B1 arr1 ad1 Ec1 Ej1 vth1
Iext1 = Iext;
Gs1 = Gs;
Gg1 = Gg;
Gc1 = Gc;
C1 = C;
B1 = B;
arr1 = arr;
ad1 = ad;
Ec1 = Ec;
Ej1 = Ej;
vth1 = vth;

end
function [Iext, Gs, Gg, Gc, C, B, arr, ad, Ec, Ej, vth] = get_params()

global Iext1 Gs1 Gg1 Gc1 C1 B1 arr1 ad1 Ec1 Ej1 vth1
Iext = Iext1;
Gs = Gs1;
Gg = Gg1;
Gc = Gc1;
C = C1;
B = B1;
arr = arr1;
ad = ad1;
Ec = Ec1;
Ej = Ej1;
vth = vth1;

end